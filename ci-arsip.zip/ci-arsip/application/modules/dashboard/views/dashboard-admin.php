<?php $this->load->view('main/header');?>
<?php
$usernm=$this->session->userdata['username'];

?>

<section id="kontener-full">
	<header>
		<ul class="panelmenu">
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">Score Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
		</ul>
	</header><div class="clear">&nbsp;</div>
	<aside id="left">
		<div class="menu">
			<ul class="megamenu">
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">Score Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
		</ul>
		</div>
	</aside>
	<section id="main">
		<div class="grid2">
			<div class="summary rounded">
				Lorem Ipsum adalah contoh teks atau dummy dalam industri percetakan dan penataan huruf atau typesetting. Lorem Ipsum telah menjadi standar contoh teks sejak tahun 1500an, saat seorang tukang cetak yang tidak dikenal mengambil sebuah kumpulan teks dan mengacaknya untuk menjadi sebuah buku contoh huruf. Ia tidak hanya bertahan selama 5 abad, tapi juga telah beralih ke penataan huruf elektronik, tanpa ada perubahan apapun. Ia mulai dipopulerkan pada tahun 1960 dengan diluncurkannya lembaran-lembaran Letraset yang menggunakan kalimat-kalimat dari Lorem Ipsum, dan seiring munculnya perangkat lunak Desktop Publishing seperti Aldus PageMaker juga memiliki versi Lorem Ipsum.
			</div>
			<div class="summary rounded">
				Lorem Ipsum adalah contoh teks atau dummy dalam industri percetakan dan penataan huruf atau typesetting. Lorem Ipsum telah menjadi standar contoh teks sejak tahun 1500an, saat seorang tukang cetak yang tidak dikenal mengambil sebuah kumpulan teks dan mengacaknya untuk menjadi sebuah buku contoh huruf. Ia tidak hanya bertahan selama 5 abad, tapi juga telah beralih ke penataan huruf elektronik, tanpa ada perubahan apapun. Ia mulai dipopulerkan pada tahun 1960 dengan diluncurkannya lembaran-lembaran Letraset yang menggunakan kalimat-kalimat dari Lorem Ipsum, dan seiring munculnya perangkat lunak Desktop Publishing seperti Aldus PageMaker juga memiliki versi Lorem Ipsum.
			</div>
		</div>
		<div class="grid2">
			<div class="summary rounded">
				Lorem Ipsum adalah contoh teks atau dummy dalam industri percetakan dan penataan huruf atau typesetting. Lorem Ipsum telah menjadi standar contoh teks sejak tahun 1500an, saat seorang tukang cetak yang tidak dikenal mengambil sebuah kumpulan teks dan mengacaknya untuk menjadi sebuah buku contoh huruf. Ia tidak hanya bertahan selama 5 abad, tapi juga telah beralih ke penataan huruf elektronik, tanpa ada perubahan apapun. Ia mulai dipopulerkan pada tahun 1960 dengan diluncurkannya lembaran-lembaran Letraset yang menggunakan kalimat-kalimat dari Lorem Ipsum, dan seiring munculnya perangkat lunak Desktop Publishing seperti Aldus PageMaker juga memiliki versi Lorem Ipsum.
				Sudah merupakan fakta bahwa seorang pembaca akan terpengaruh oleh isi tulisan dari sebuah halaman saat ia melihat tata letaknya. Maksud penggunaan Lorem Ipsum adalah karena ia kurang lebih memiliki penyebaran huruf yang normal, ketimbang menggunakan kalimat seperti "Bagian isi disini, bagian isi disini", sehingga ia seolah menjadi naskah Inggris yang bisa dibaca. Banyak paket Desktop Publishing dan editor situs web yang kini menggunakan Lorem Ipsum sebagai contoh teks. Karenanya pencarian terhadap kalimat "Lorem Ipsum" akan berujung pada banyak situs web yang masih dalam tahap pengembangan. Berbagai versi juga telah berubah dari tahun ke tahun, kadang karena tidak sengaja, kadang karena disengaja (misalnya karena dimasukkan unsur humor atau semacamnya)
 s
			</div>
		</div>
		</section>
	<aside id="right">
		<div class="menu">
			<ul class="megamenu">
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">Score Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
			<li><a href="#" alt="" title="">User Management</a></li>
		</ul>
		</div>
	</aside>
</section>
<?php $this->load->view('main/footer');?>