
      <link type="text/css" href="<?php echo base_url();?>assets/css/custom-theme/jquery-ui-1.9.2.custom.css" rel="stylesheet" />
      <link rel="stylesheet" href="<?php echo base_url();?>assets/datatables/css/jquery.dataTables_themeroller.css" />
      <!-- main styles -->
      <link rel="stylesheet" href="<?php echo base_url();?>assets/style.css" />      
     
      <!--[if lt IE 9]>
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/custom-theme/jquery.ui.1.9.2.ie.css"/>
      <![endif]-->    

    <!-- main jQUery & jQuery UI js -->
            <script src="<?php echo base_url();?>assets/js/jquery-1.8.3.min.js"></script>
            <script src="<?php echo base_url();?>assets/js/jquery-ui-1.9.2.custom.min.js"></script>
	<!-- main bootstrap js -->
      <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
      <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap-scroll-modal.js"></script>
			<script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap-fluid-modal.js"></script>
    		<script src="<?php echo base_url();?>assets/datatables/js/jquery.dataTables.min.js" /></script>
    		<script src="<?php echo base_url();?>assets/js/jquery.jeditable.mini.js" /></script>
    
        <!--[if lte IE 9]>
            <script src="<?php echo base_url();?>assets/js/ie/html5.js"></script>
			<script src="<?php echo base_url();?>assets/js/ie/respond.min.js"></script>
        <![endif]-->